#ifndef MENUS_H_
#define MENUS_H_

char menuPrincipal();
char menuInicioSesionCliente();
char menuCliente();
char menuAdministrador();
char menuCatalogo();

#endif /* MENUS_H_ */
